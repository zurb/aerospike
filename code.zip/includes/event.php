<section class="content-section event bold-callout">
  <div class="section-heading-container row">
    <div class="small-12 columns">
      <h2 class="section-heading">
        <span class="metadata">Upcoming Event &bull; 4/12/2015 in Las Vegas</span>
        Aerospike Las Vegas 2015
      </h2>
      <h5>Replatforming on Aerospike DB</h5>
    </div>
  </div>
  <div class="points-for-event">
    <div class="row">
      <div class="small-12 medium-8 columns medium-centered">
        <p class="lead hero-unit">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi quis vehicula enim, et lobortis libero. Duis at quam augue. In egestas scelerisque semper. Donec varius eros in pellentesque egestas. Nam nisi felis, commodo ac bibendum eu, facilisis quis turpis. Proin ultricies faucibus est quis pharetra. </p>
        <a href="events.php" class="button inverted-button">Learn More</a>              
      </div>
    </div>   
  </div>     
</section>