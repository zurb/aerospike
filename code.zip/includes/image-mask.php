<img data-interchange="[images/white-triangle-mask.svg, (default)], [images/white-triangle-mask-xlarge.svg, (xlarge)]" alt="mask" class="hero-mask">
<noscript><img src="images/white-triangle-mask.svg" alt="mask" class="hero-mask"></noscript> 

<!--
<?#php if($bodyClass==="homepage") { ?>
	<img data-interchange="[images/gray-triangle-mask.svg, (default)], [images/gray-triangle-mask-xlarge.svg, (xlarge)]" alt="mask" class="hero-mask">
	<noscript><img src="images/gray-triangle-mask.svg" alt="mask" class="hero-mask"></noscript> 
<?#php } else { ?>
	<img data-interchange="[images/white-triangle-mask.svg, (default)], [images/white-triangle-mask-xlarge.svg, (xlarge)]" alt="mask" class="hero-mask">
	<noscript><img src="images/white-triangle-mask.svg" alt="mask" class="hero-mask"></noscript> 
<?#php } ?>
-->