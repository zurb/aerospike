<?php
$aerospike_client_downloads = Array(
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "C / C++", 
		download_item_name => "C / C++",
		download_item_metadata => "3.1.11"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Java", 
		download_item_name => "Java",
		download_item_metadata => "3.1.1"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Go", 
		download_item_name => "Go",
		download_item_metadata => "1.4.1"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "C# / .NET", 
		download_item_name => "C# / .NET",
		download_item_metadata => "3.1.1"
	),	
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Node.js", 
		download_item_name => "Node.js",
		download_item_metadata => "1.0.37"
	),		
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "C libevent", 
		download_item_name => "C libevent",
		download_item_metadata => "2.1.41"
	),			
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "PHP", 
		download_item_name => "PHP",
		download_item_metadata => "3.3.14"
	),	
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Erlang", 
		download_item_name => "Erlang",
		download_item_metadata => "2.1.2"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Python", 
		download_item_name => "Python",
		download_item_metadata => "1.0.43"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Ruby", 
		download_item_name => "Ruby",
		download_item_metadata => "1.0.4"
	),	
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Perl", 
		download_item_name => "Perl",
		download_item_metadata => "2.1.34"
	)					
);
?>