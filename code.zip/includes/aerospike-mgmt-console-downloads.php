<?php
$aerospike_mgmt_console_downloads = Array(
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Redhat 5/6", 
		download_item_name => "Redhat 5/6",
		download_item_metadata => ".rpm packages"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Ubuntu 12.04+", 
		download_item_name => "Ubuntu 12.04+",
		download_item_metadata => ".deb packages"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Debian 6+", 
		download_item_name => "Debian 6+",
		download_item_metadata => ".deb packages"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Mac OS X 10.7+", 
		download_item_name => "Mac OS X 10.7+",
		download_item_metadata => ".tar.gz package"
	)				
);
?>