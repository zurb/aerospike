<section class="content-section cta-get-started">
  <div class="section-heading-container row">
    <div class="medium-6 medium-centered large-centered columns">
      <h2 class="section-heading">Build Your First App</h2>
      <h5 class="subhead">Build, Deploy and Run Today.</h5>
    </div>
  </div>
  <div class="points-for-getting-started row">
    <div class="small-12 columns">
      <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eu eros vitae diam lacinia luctus. Donec id orci sapien.</p>
      <a href="#" class="button">Download Community Edition</a>
      <p>or <a href="#" class="link-button">Try Burro Now</a></p>
    </div>
  </div>
</section> 