<?php 
$aerospike_server_downloads = Array(
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "RedHat 6", 
		download_item_name => "RedHat 6",
		download_item_metadata => ".rpm package"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Ubuntu 12.04+", 
		download_item_name => "Ubuntu 12.04+",
		download_item_metadata => ".deb packages"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Debian 6", 
		download_item_name => "Debian 6",
		download_item_metadata => ".deb packages"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Debian 7", 
		download_item_name => "Debian 7",
		download_item_metadata => ".deb packages"
	),	
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Linux", 
		download_item_name => "Linux",
		download_item_metadata => ".tar.gz package"
	),		
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Mac OS X", 
		download_item_name => "Mac OS X",
		download_item_metadata => "Vagrant Box"
	),			
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Windows", 
		download_item_name => "Windows",
		download_item_metadata => "Vagrant Box"
	),	
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Amazon EC2", 
		download_item_name => "Amazon EC2",
		download_item_metadata => "Cloud"
	),
	array(
		download_item_thumb => "http://placehold.it/30x30",
		download_item_alt => "Google Compute Engine", 
		download_item_name => "Google Compute Engine",
		download_item_metadata => "Cloud"
	)						
);