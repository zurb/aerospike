	  <script src="bower_components/jquery/dist/jquery.min.js"></script>
	  <script src="bower_components/foundation/js/foundation.min.js"></script>
	  <script src="js/app.js"></script>
	</body>
</html> 