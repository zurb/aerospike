<section class="content-section brands">
  <div class="section-heading-container row">
    <div class="small-12 columns">
      <h4>
        Trusted by the World's Biggest Brands
      </h4>
    </div>
  </div>
  <div class="row brands-container">
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-adform.png" alt="AdForm">
      </a>
    </div>
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-kayak.png" alt="Kayak">
      </a>            
    </div>
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-appnexus.png" alt="AppNexus">
      </a>            
    </div>
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-bluekai.png" alt="bluekai">
      </a>            
    </div>
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-admarketplace.png" alt="adMarketplace">
      </a>            
    </div>     
    <div class="small-6 medium-2 columns">
      <a href="#">
        <img src="images/brands-chango.png" alt="Chango">
      </a>            
    </div>                    
  </div>
</section>     