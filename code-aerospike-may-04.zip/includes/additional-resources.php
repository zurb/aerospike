<section class="content-section additional-resources">
  <div class="section-heading-container row">
    <div class="small-12 columns">
      <h4>Additional Resources</h4>
      <p class="subhead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut rhoncus est. Vestibulum tristique vestibulum purus, et rutrum urna fermentum in.</p>      
    </div>
  </div>
  <div class="points-for-additional-resources">
    <div class="points-for-additional-resources row">
      <div class="additional-resources-points medium-4 small-12 columns end">
        <div class="additional-resources-container"> 
          <a href="#">
            <img src="http://placehold.it/400x200" alt="Datasheet: Reaching 1 Million transactions per second on Intel P3700 SSDs" class="additional-resources-thumbnail">
          </a>
          <div class="panel-content">
            <h5 class="additional-resources-heading">
              <a href="#">Reaching 1 Million transactions per second on Intel P3700 SSDs</a>
            </h5>
            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec mauris magna, vulputate ac efficitur ac.</p>
          </div>
        </div>               
      </div>     
      <div class="additional-resources-points medium-4 small-12 columns end">
        <div class="additional-resources-container"> 
          <a href="#">
            <img src="http://placehold.it/400x200" alt="Datasheet: Reaching 1 Million transactions per second on Intel P3700 SSDs" class="additional-resources-thumbnail">
          </a>
          <div class="panel-content">              
            <h5 class="services-heading">
              <a href="#">Flash-optimized in-memory, NoSQL Database Data Sheet</a>
            </h5>
            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec mauris magna, vulputate ac efficitur ac.</p>
          </div>
        </div>               
      </div>         
      <div class="additional-resources-points medium-4 small-12 columns end">
        <div class="additional-resources-container"> 
          <a href="#">
            <img src="http://placehold.it/400x200" alt="Datasheet: Reaching 1 Million transactions per second on Intel P3700 SSDs" class="additional-resources-thumbnail">
          </a>
          <div class="panel-content">
            <h5 class="services-heading">
              <a href="#">Aerospike Architecture Overview Whitepaper</a>
            </h5>
            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec mauris magna, vulputate ac efficitur ac.</p>
          </div>
        </div>               
      </div>                                                        
    </div>
  </div>
</section>   